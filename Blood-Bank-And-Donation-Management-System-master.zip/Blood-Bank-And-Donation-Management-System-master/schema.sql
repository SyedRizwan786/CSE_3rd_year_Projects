---

-- PostgreSQL Database Schema
-- Blood Bank & Donation Management System
-- This schema creates all tables required for the Flask application.

---

-- Example command to create database manually:
-- CREATE DATABASE blood_donation;

-- Example command to run this schema file:
-- psql -d blood_donation -f schema.sql

---

-- Start a database transaction
-- If any statement fails, everything can be rolled back.

---

BEGIN;

---

-- Drop existing tables if they already exist
-- CASCADE ensures dependent tables are also removed
-- This helps when re-running schema during development

---

DROP TABLE IF EXISTS blood_requests CASCADE;
DROP TABLE IF EXISTS blood_stock CASCADE;
DROP TABLE IF EXISTS donors CASCADE;
DROP TABLE IF EXISTS contact_queries CASCADE;
DROP TABLE IF EXISTS contact_info CASCADE;
DROP TABLE IF EXISTS pages CASCADE;
DROP TABLE IF EXISTS hospitals CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS admins CASCADE;
DROP TABLE IF EXISTS blood_groups CASCADE;

---

-- BLOOD GROUPS TABLE
-- Stores all available blood types
-- Example: A+, B+, O-, etc.

---

CREATE TABLE blood_groups (

id SERIAL PRIMARY KEY,
-- SERIAL automatically generates incremental integer values

blood_group VARCHAR(10) NOT NULL UNIQUE
-- blood group name (must be unique)

);

---

-- ADMINS TABLE
-- Stores administrator login information

---

CREATE TABLE admins (

id SERIAL PRIMARY KEY,

name VARCHAR(100) NOT NULL,
-- admin full name

username VARCHAR(50) NOT NULL UNIQUE,
-- admin login username

password_hash TEXT NOT NULL,
-- hashed password (created using werkzeug)

created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
-- timestamp when admin account was created

);

---

-- USERS TABLE
-- Stores normal user accounts (website users)

---

CREATE TABLE users (

id SERIAL PRIMARY KEY,

full_name VARCHAR(100) NOT NULL,
-- user full name

email VARCHAR(120) NOT NULL UNIQUE,
-- email must be unique for login

phone VARCHAR(20),
-- optional phone number

password_hash TEXT NOT NULL,
-- encrypted password stored securely

created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
-- record creation timestamp

);

---

-- HOSPITALS TABLE
-- Stores hospital information where blood may be requested

---

CREATE TABLE hospitals (

id SERIAL PRIMARY KEY,

name VARCHAR(150) NOT NULL,
-- hospital name

address TEXT,
-- hospital address

phone VARCHAR(20),
-- hospital contact number

email VARCHAR(120),
-- hospital email

created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()

);

---

-- DONORS TABLE
-- Stores people who are willing to donate blood

---

CREATE TABLE donors (

id SERIAL PRIMARY KEY,

name VARCHAR(100) NOT NULL,
-- donor name

phone VARCHAR(20) NOT NULL,
-- donor contact number

email VARCHAR(120),
-- optional email

age INTEGER NOT NULL
CHECK (age >= 0 AND age <= 120),
-- validation rule to ensure valid age

gender VARCHAR(10) NOT NULL,
-- gender field

blood_group_id INTEGER NOT NULL
REFERENCES blood_groups(id)
ON DELETE RESTRICT,
-- foreign key referencing blood_groups table

address TEXT NOT NULL,
-- donor address

user_id INTEGER
REFERENCES users(id)
ON DELETE SET NULL,
-- if user account deleted, donor remains but user_id becomes NULL

created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()

);

---

-- Index to speed up searching donors by blood group

---

CREATE INDEX donors_blood_group_idx
ON donors(blood_group_id);

---

-- BLOOD STOCK TABLE
-- Stores available blood units for each blood group

---

CREATE TABLE blood_stock (

id SERIAL PRIMARY KEY,

blood_group_id INTEGER NOT NULL UNIQUE
REFERENCES blood_groups(id)
ON DELETE RESTRICT,
-- one record per blood group

units INTEGER NOT NULL DEFAULT 0
CHECK (units >= 0),
-- number of available units

updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
-- last update time

);

---

-- BLOOD REQUESTS TABLE
-- Stores requests made by people needing blood

---

CREATE TABLE blood_requests (

id SERIAL PRIMARY KEY,

requester_name VARCHAR(100) NOT NULL,
-- person requesting blood

requester_phone VARCHAR(20) NOT NULL,

requester_email VARCHAR(120),

blood_group_id INTEGER NOT NULL
REFERENCES blood_groups(id)
ON DELETE RESTRICT,

units_requested INTEGER NOT NULL DEFAULT 1
CHECK (units_requested >= 1),
-- minimum 1 unit required

reason TEXT NOT NULL,
-- reason for blood request

hospital_id INTEGER
REFERENCES hospitals(id)
ON DELETE SET NULL,

status VARCHAR(20) NOT NULL DEFAULT 'pending',
-- request status values:
-- pending, approved, rejected, fulfilled

requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
-- request creation time

processed_at TIMESTAMPTZ,
-- time when admin processed request

processed_by_admin_id INTEGER
REFERENCES admins(id)
ON DELETE SET NULL,

notes TEXT,
-- additional admin notes

user_id INTEGER
REFERENCES users(id)
ON DELETE SET NULL
-- user who submitted the request

);

---

-- Index to speed up status filtering (pending, approved etc.)

---

CREATE INDEX blood_requests_status_idx
ON blood_requests(status);

---

-- PAGES TABLE
-- Used for CMS (content management system)
-- Admin can edit website content dynamically

---

CREATE TABLE pages (

id SERIAL PRIMARY KEY,

name VARCHAR(255) NOT NULL,
-- page title

type VARCHAR(50) NOT NULL UNIQUE,
-- unique page identifier

data TEXT NOT NULL
-- HTML content stored here

);

---

-- CONTACT INFO TABLE
-- Stores contact details shown on website contact page

---

CREATE TABLE contact_info (

id SERIAL PRIMARY KEY,

address TEXT NOT NULL,

email VARCHAR(120) NOT NULL,

phone VARCHAR(30) NOT NULL

);

---

-- CONTACT QUERIES TABLE
-- Stores messages submitted by users through contact form

---

CREATE TABLE contact_queries (

id SERIAL PRIMARY KEY,

name VARCHAR(100) NOT NULL,
-- person name

email VARCHAR(120) NOT NULL,

phone VARCHAR(20) NOT NULL,

message TEXT NOT NULL,
-- user message

created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

status SMALLINT NOT NULL DEFAULT 2
-- 1 = Read
-- 2 = Pending

);

---

-- SEED DATA
-- Initial data inserted into database

---

-- Insert all blood groups
INSERT INTO blood_groups(blood_group) VALUES
('B+'),('B-'),('A+'),('O+'),('O-'),('A-'),('AB+'),('AB-');

-- Ensure every blood group has a blood_stock record
INSERT INTO blood_stock(blood_group_id, units)
SELECT id, 0 FROM blood_groups
ON CONFLICT (blood_group_id) DO NOTHING;

---

-- Default admin login
-- Username: admin
-- Password: 123
-- Password stored as hashed value for security

---

INSERT INTO admins(name, username, password_hash) VALUES
(
'Syed',
'admin',
'scrypt:32768:8:1$M53GfqkHLQPIpxDH$9c9e72cfd8e98a48718ad8919669424b2eb97a316dca451cb23aca8979da7d19dca82924964c4c16c3b7e4fe9d72023d3657ae82d95944b3d1b340e298fdbf92'
);

---

-- Default contact information for website

---

INSERT INTO contact_info(address, email, phone) VALUES
(
'Syed, Khammam (507002)',
'[bloodbank@gmail.com](mailto:bloodbank@gmail.com)',
'7981678436'
);

---

-- Insert default content for website pages
-- These are displayed on homepage and other pages

---

INSERT INTO pages(name, type, data) VALUES

('Why Become Donor', 'donor',
$$Blood is the most precious gift anyone can give to another person — the gift of life.$$),

('About Us', 'aboutus',
$$Blood bank is a place where blood collected from donation events is stored and managed.$$),

('The Need For Blood', 'needforblood',
$$Patients undergoing surgery, cancer treatment, or trauma care need blood.$$),

('Blood Tips', 'bloodtips',
$$Stay hydrated, eat healthy food, and rest after donating blood.$$),

('Who you could Help', 'whoyouhelp',
$$Every 2 seconds someone in the world needs blood.$$),

('Blood Groups', 'bloodgroups',
$$Blood groups include A+, A-, B+, B-, O+, O-, AB+, AB-. $$),

('Universal Donors And Recipients', 'universal',
$$O- is universal donor and AB+ is universal recipient.$$);

---

-- Commit transaction (save all changes permanently)

---

COMMIT;
