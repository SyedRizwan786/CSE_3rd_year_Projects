﻿(function () {
  // Reserved for small UI helpers.
})();
