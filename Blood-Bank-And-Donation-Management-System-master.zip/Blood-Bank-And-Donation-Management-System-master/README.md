# Blood Bank & Donation Management System

Project documentation lives in `README_FLASK.md`.

