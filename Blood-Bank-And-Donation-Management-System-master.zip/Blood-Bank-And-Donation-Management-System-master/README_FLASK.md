# Blood Bank & Donation Management System (Flask + PostgreSQL)

This project is a web-based system to manage blood donors, blood stock, and blood requests with two main roles:

- **User (public/registered)**: browse donors/stock, create account, login, register as donor, request blood, track request status.
- **Admin**: manage donor records, update blood stock, process blood requests, manage contact queries, and edit website CMS content.

## What We Built (Major Modules)

- **Authentication**
  - User registration + login (passwords stored as hashes).
  - Admin login portal.
- **Donor Management**
  - Donor registration form (name, contact, age, gender, blood group, address).
  - Donor list with blood-group filtering.
  - "Need Blood" donor search by blood group.
  - Admin CRUD for donors (add/edit/delete).
- **Blood Stock**
  - Public "Blood Availability" page.
  - Admin stock management: update available units per blood group.
- **Blood Requests**
  - User blood request form (blood group, units, reason, requester details).
  - Admin can update request status and delete requests.
  - Request lifecycle: `pending` -> `approved` / `rejected` -> `fulfilled`.
- **Contact & Queries**
  - Contact page with form submission (stored in DB).
  - Admin view: mark queries read / delete.
  - Admin can manage the contact info displayed on the site.
- **CMS Pages**
  - Content is stored in the database (`pages` table) and rendered on site pages like About / Why Donate / Need for Blood etc.
  - Admin can edit page content from the admin panel.

## Application Workflow

### 1) Public Visitor Flow

1. Open the website homepage to view basic information and dynamic CMS content.
2. View **Donors** list (optionally filter by blood group).
3. View **Blood Stock** (available units per blood group).
4. Use **Contact** form to send a query/message (stored for admin to review).
5. Create an account to access the user dashboard features.

### 2) Registered User Flow

1. **Register** a new user account (name, email, phone, password).
2. **Login** using email + password.
3. Use the **Dashboard** to:
   - Register as a **Donor** (adds a record to the `donors` table linked to the user when available).
   - Create a **Blood Request** (adds a record to the `blood_requests` table).
   - Track your requests and their statuses.
4. **Logout**.

### 3) Admin Flow

1. Login via the Admin portal.
2. Admin dashboard shows key counts (donors, queries, pending requests).
3. Admin operations:
   - **Donors**: add/edit/delete donor records.
   - **Blood Stock**: update units per blood group.
   - **Blood Requests**: review and update status (`pending/approved/rejected/fulfilled`), delete if needed.
   - **Contact Queries**: review messages, mark as read, delete.
   - **Pages (CMS)**: edit website informational content stored in DB.
   - **Contact Info**: update address/phone/email shown on Contact page.
4. Logout.

## Database Design (schema.sql)

Database tables used:

- `admins` (admin credentials)
- `users` (registered user accounts)
- `donors` (donor records)
- `blood_groups` (A+, O-, etc.)
- `blood_stock` (units per blood group)
- `blood_requests` (requests + statuses)
- `pages` (CMS content)
- `contact_info` (site contact details)
- `contact_queries` (messages sent via contact form)
- `hospitals` (optional hospital reference for requests)

Seed data included in `schema.sql`:

- Blood groups + initial stock rows
- Default admin user
- Default CMS page content
- Default contact information

## Project Structure

- `app.py` — Flask application entry point.
- `schema.sql` — PostgreSQL schema + seed data.
- `templates/` — Jinja2 UI templates (user + admin pages).
- `static/` — CSS/JS/images.
- `.env.example` — environment variables template.
- `requirements.txt` — Python dependencies.

## Setup (Local)

1. Create a PostgreSQL database (example name: `blood_donation`).
2. Create a `.env` file (copy from `.env.example`) and fill your PostgreSQL credentials.
3. Install dependencies:
   - `pip install -r requirements.txt`
4. Initialize database tables + seed data:
   - `psql -d blood_donation -f schema.sql`
5. Run the app:
   - `python app.py`

Open `http://localhost:5000`.

## Admin Login

- URL: `http://localhost:5000/admin`
- Default credentials (from `schema.sql` seed):
  - Username: `admin`
  - Password: `123`
