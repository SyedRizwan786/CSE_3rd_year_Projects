# Importing built-in Python modules and external libraries

import os              # os module is used to interact with operating system (environment variables, file paths etc.)
import sys             # sys module is used to interact with Python runtime environment (arguments, exit etc.)
from functools import wraps   # wraps is used to preserve function metadata when creating decorators
from pathlib import Path      # Path helps handle file system paths in an object-oriented way

# Import PostgreSQL database library
import psycopg2        # psycopg2 is a PostgreSQL adapter for Python

# Import dotenv to read environment variables from .env file
from dotenv import load_dotenv

# Import Flask framework and its components
from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for

# RealDictCursor returns database results as dictionary instead of tuple
from psycopg2.extras import RealDictCursor

# Import security functions to hash passwords
from werkzeug.security import check_password_hash, generate_password_hash