import os
import sys
from functools import wraps
from pathlib import Path

import psycopg2
from dotenv import load_dotenv
from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from psycopg2.extras import RealDictCursor
from werkzeug.security import check_password_hash, generate_password_hash

# Base directory of the application (where this file resides)
BASE_DIR = Path(__file__).resolve().parent
# Load environment variables from a .env file in the base directory (if present)
load_dotenv(BASE_DIR / ".env")


def _build_dsn() -> str:
    """
    Build a PostgreSQL DSN (Data Source Name) string from environment variables.
    Priority: DATABASE_URL (e.g., for Heroku) > individual PG* variables > defaults.
    Includes connect_timeout=5 to avoid long hangs if DB is unreachable.
    """
    database_url = os.getenv("DATABASE_URL")
    if database_url:
        return database_url

    host = os.getenv("PGHOST", "localhost")
    port = os.getenv("PGPORT", "5432")
    dbname = os.getenv("PGDATABASE", "blood_donation")
    user = os.getenv("PGUSER", "postgres")
    password = os.getenv("PGPASSWORD", "postgres")
    parts = [f"host={host}", f"port={port}", f"dbname={dbname}", f"user={user}"]
    if password:
        parts.append(f"password={password}")
    parts.append("connect_timeout=5")
    return " ".join(parts)


def get_db():
    """
    Get a PostgreSQL connection for the current request context.
    Stores the connection in Flask's 'g' object to reuse it during the request.
    Sets autocommit=True so every statement is committed immediately (no manual commit needed).
    """
    if "db" not in g:
        g.db = psycopg2.connect(_build_dsn())
        g.db.autocommit = True
    return g.db


def db_fetch_all(sql: str, params=None):
    """
    Execute a query and return all rows as a list of dictionaries (RealDictCursor).
    """
    with get_db().cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(sql, params or ())
        return cur.fetchall()


def db_fetch_one(sql: str, params=None):
    """
    Execute a query and return a single row as a dictionary, or None if no rows.
    """
    with get_db().cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(sql, params or ())
        return cur.fetchone()


def db_execute(sql: str, params=None):
    """
    Execute a query that does not return rows (INSERT, UPDATE, DELETE).
    Autocommit is on, so changes are applied immediately.
    """
    with get_db().cursor() as cur:
        cur.execute(sql, params or ())


def user_login_required(view):
    """
    Decorator to protect routes that require a regular user to be logged in.
    If not logged in, flashes a warning and redirects to the login page,
    preserving the original request path as the 'next' parameter.
    """
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please login to continue.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def admin_login_required(view):
    """
    Decorator to protect routes that require an admin to be logged in.
    If not logged in, flashes a warning and redirects to the admin login page.
    """
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_id"):
            flash("Please login as admin to continue.", "warning")
            return redirect(url_for("admin"))
        return view(*args, **kwargs)
    return wrapped


def create_app():
    """
    Application factory pattern: creates and configures the Flask app.
    This is the main function that defines all routes and returns the app instance.
    """
    app = Flask(__name__)
    # Secret key for sessions – should be set via environment variable in production
    app.secret_key = os.getenv("SECRET_KEY", "dev-secret-key-change-me")

    @app.teardown_appcontext
    def close_db(_exc):
        """
        Close the database connection after each request.
        The connection is stored in Flask's 'g' object and is closed here.
        """
        db = g.pop("db", None)
        if db is not None:
            db.close()

    @app.context_processor
    def inject_globals():
        """
        Inject current user and current admin information into all templates.
        This allows templates to access {{ current_user.name }} and {{ current_admin.username }}.
        """
        return {
            "current_user": {
                "id": session.get("user_id"),
                "name": session.get("user_name"),
                "email": session.get("user_email"),
            },
            "current_admin": {
                "id": session.get("admin_id"),
                "username": session.get("admin_username"),
                "name": session.get("admin_name"),
            },
        }

    # Helper function to fetch all blood groups (used in multiple dropdowns)
    def _blood_groups():
        return db_fetch_all("SELECT id, blood_group FROM blood_groups ORDER BY blood_group;")

    # Helper function to fetch a page's content by its type (e.g., 'aboutus', 'needforblood')
    def _page(type_):
        return db_fetch_one("SELECT type, name, data FROM pages WHERE type=%s;", (type_,))

    # ------------------------------
    # Public routes (no login required)
    # ------------------------------

    @app.get("/")
    def index():
        """
        Home page: shows 6 random donors and several page sections fetched from the 'pages' table.
        The sections are: need for blood, blood tips, who you help, blood groups, universal.
        """
        donors = db_fetch_all(
            """
            SELECT d.id, d.name, d.phone, d.email, d.age, d.gender, d.address, bg.blood_group
            FROM donors d
            JOIN blood_groups bg ON bg.id = d.blood_group_id
            ORDER BY RANDOM()
            LIMIT 6;
            """
        )
        page_need = _page("needforblood")
        page_tips = _page("bloodtips")
        page_help = _page("whoyouhelp")
        page_groups = _page("bloodgroups")
        page_universal = _page("universal")
        return render_template(
            "index.html",
            donors=donors,
            page_need=page_need,
            page_tips=page_tips,
            page_help=page_help,
            page_groups=page_groups,
            page_universal=page_universal,
        )

    @app.get("/about")
    def about():
        """About Us page – content from 'aboutus' page in database."""
        return render_template("page.html", page=_page("aboutus"), title="About Us", image="banner_590x300.jpg")

    @app.get("/why-donate-blood")
    def why_donate_blood():
        """Why Donate Blood page – content from 'donor' page in database."""
        return render_template(
            "page.html",
            page=_page("donor"),
            title="Why Should I Donate Blood?",
            image="08f2fccc45d2564f74ead4a6d5086871.png",
        )

    @app.route("/register", methods=["GET", "POST"])
    def register_donor():
        """
        Donor registration page (for adding oneself as a donor).
        This does NOT create a user account; it just adds a donor record.
        If a user is logged in, the donor is linked to that user_id.
        """
        if request.method == "POST":
            # Collect form data
            name = request.form.get("fullname", "").strip()
            phone = request.form.get("mobileno", "").strip()
            email = request.form.get("emailid", "").strip() or None
            age = request.form.get("age", "").strip()
            gender = request.form.get("gender", "").strip()
            blood_group_id = request.form.get("blood")
            address = request.form.get("address", "").strip()

            if not (name and phone and age and gender and blood_group_id and address):
                flash("Please fill all required fields.", "danger")
                return redirect(url_for("register_donor"))

            try:
                age_int = int(age)
            except ValueError:
                flash("Age must be a number.", "danger")
                return redirect(url_for("register_donor"))

            # Insert donor record; if user is logged in, link to their user_id
            db_execute(
                """
                INSERT INTO donors(name, phone, email, age, gender, blood_group_id, address, user_id)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s);
                """,
                (name, phone, email, age_int, gender, int(blood_group_id), address, session.get("user_id")),
            )
            flash("Thank you! Donor registered successfully.", "success")
            return redirect(url_for("index"))

        # GET request: show the form with blood group dropdown
        return render_template("register.html", blood_groups=_blood_groups())

    @app.route("/need-blood", methods=["GET", "POST"])
    def need_blood():
        """
        Need Blood page: allows searching for donors by blood group.
        On POST, fetches up to 5 random donors of the selected group.
        """
        donors = []
        selected_bg = None
        if request.method == "POST":
            selected_bg = request.form.get("blood")
            if selected_bg:
                donors = db_fetch_all(
                    """
                    SELECT d.id, d.name, d.phone, d.email, d.age, d.gender, d.address, bg.blood_group
                    FROM donors d
                    JOIN blood_groups bg ON bg.id=d.blood_group_id
                    WHERE d.blood_group_id=%s
                    ORDER BY RANDOM()
                    LIMIT 5;
                    """,
                    (int(selected_bg),),
                )
                if not donors:
                    flash("No donor found for the selected blood group.", "danger")
        return render_template("need_blood.html", blood_groups=_blood_groups(), donors=donors, selected_bg=selected_bg)

    @app.get("/donors")
    def donors():
        """
        Donors listing page: shows all donors, optionally filtered by blood group.
        Supports a query parameter ?blood=id to filter.
        """
        bg = request.args.get("blood")
        params = []
        where = ""
        if bg:
            where = "WHERE d.blood_group_id=%s"
            params.append(int(bg))
        rows = db_fetch_all(
            f"""
            SELECT d.id, d.name, d.phone, d.email, d.age, d.gender, d.address, bg.blood_group
            FROM donors d
            JOIN blood_groups bg ON bg.id=d.blood_group_id
            {where}
            ORDER BY d.id DESC;
            """,
            tuple(params),
        )
        return render_template("donors.html", donors=rows, blood_groups=_blood_groups(), selected_bg=bg)

    @app.route("/request-blood", methods=["GET", "POST"])
    def request_blood():
        """
        Blood request page: allows anyone to submit a request for blood.
        If a user is logged in, the request is linked to that user_id.
        """
        if request.method == "POST":
            name = request.form.get("fullname", "").strip()
            phone = request.form.get("mobileno", "").strip()
            email = request.form.get("emailid", "").strip() or None
            blood_group_id = request.form.get("blood")
            units = request.form.get("units", "1").strip() or "1"
            reason = request.form.get("reason", "").strip()

            if not (name and phone and blood_group_id and reason):
                flash("Please fill all required fields.", "danger")
                return redirect(url_for("request_blood"))

            try:
                units_int = max(1, int(units))
            except ValueError:
                flash("Units must be a number.", "danger")
                return redirect(url_for("request_blood"))

            db_execute(
                """
                INSERT INTO blood_requests(requester_name, requester_phone, requester_email, blood_group_id, units_requested, reason, user_id)
                VALUES (%s,%s,%s,%s,%s,%s,%s);
                """,
                (name, phone, email, int(blood_group_id), units_int, reason, session.get("user_id")),
            )
            flash("Blood request submitted successfully.", "success")
            return redirect(url_for("blood_stock"))

        return render_template("blood_request.html", blood_groups=_blood_groups())

    @app.get("/blood-stock")
    def blood_stock():
        """
        Public blood stock page: shows current units available for each blood group.
        Data comes from the blood_stock table (left join with blood_groups).
        """
        stock = db_fetch_all(
            """
            SELECT bg.id AS blood_group_id, bg.blood_group, COALESCE(bs.units,0) AS units, bs.updated_at
            FROM blood_groups bg
            LEFT JOIN blood_stock bs ON bs.blood_group_id = bg.id
            ORDER BY bg.blood_group;
            """
        )
        return render_template("blood_stock.html", stock=stock)

    @app.route("/contact", methods=["GET", "POST"])
    def contact():
        """
        Contact page: shows contact info (address, email, phone) and allows visitors
        to submit a query (contact_queries table).
        """
        info = db_fetch_one("SELECT address, email, phone FROM contact_info ORDER BY id LIMIT 1;")
        if request.method == "POST":
            name = request.form.get("fullname", "").strip()
            phone = request.form.get("contactno", "").strip()
            email = request.form.get("email", "").strip()
            message = request.form.get("message", "").strip()
            if not (name and phone and email and message):
                flash("Please fill all required fields.", "danger")
                return redirect(url_for("contact"))
            db_execute(
                "INSERT INTO contact_queries(name,email,phone,message,status) VALUES (%s,%s,%s,%s,2);",
                (name, email, phone, message),
            )
            flash("Query sent. We will contact you shortly.", "success")
            return redirect(url_for("contact"))
        return render_template("contact.html", info=info)

    # ------------------------------
    # User authentication routes
    # ------------------------------

    @app.route("/user-register", methods=["GET", "POST"])
    def user_register():
        """
        User account registration page.
        Creates a new user in the 'users' table (separate from donors).
        Users can later link donor registrations to their account.
        """
        if request.method == "POST":
            full_name = request.form.get("fullname", "").strip()
            email = request.form.get("email", "").strip().lower()
            phone = request.form.get("phone", "").strip() or None
            password = request.form.get("password", "")
            confirm = request.form.get("confirm_password", "")

            if not (full_name and email and password and confirm):
                flash("Please fill all required fields.", "danger")
                return redirect(url_for("user_register"))
            if password != confirm:
                flash("Passwords do not match.", "danger")
                return redirect(url_for("user_register"))

            existing = db_fetch_one("SELECT id FROM users WHERE email=%s;", (email,))
            if existing:
                flash("Email already registered. Please login.", "warning")
                return redirect(url_for("login"))

            password_hash = generate_password_hash(password)
            db_execute(
                "INSERT INTO users(full_name,email,phone,password_hash) VALUES (%s,%s,%s,%s);",
                (full_name, email, phone, password_hash),
            )
            flash("Account created successfully. Please login.", "success")
            return redirect(url_for("login"))

        return render_template("user_register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        """
        User login page. Authenticates against the 'users' table.
        On success, stores user info in session.
        Supports a 'next' parameter to redirect to the originally requested page.
        """
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            next_url = request.form.get("next") or url_for("dashboard")
            user = db_fetch_one("SELECT id, full_name, email, password_hash FROM users WHERE email=%s;", (email,))
            if not user or not check_password_hash(user["password_hash"], password):
                flash("Invalid email or password.", "danger")
                return render_template("login.html", next_url=next_url)
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["full_name"]
            session["user_email"] = user["email"]
            flash("Logged in successfully.", "success")
            return redirect(next_url)

        return render_template("login.html", next_url=request.args.get("next") or url_for("dashboard"))

    @app.get("/logout")
    def logout():
        """User logout – clears the session and redirects to home."""
        session.clear()
        flash("Logged out.", "info")
        return redirect(url_for("index"))

    @app.get("/dashboard")
    @user_login_required
    def dashboard():
        """
        User dashboard – shows the user's blood requests and any donor registrations
        linked to their account.
        """
        requests_ = db_fetch_all(
            """
            SELECT br.id, bg.blood_group, br.units_requested, br.reason, br.status, br.requested_at
            FROM blood_requests br
            JOIN blood_groups bg ON bg.id=br.blood_group_id
            WHERE br.user_id=%s
            ORDER BY br.requested_at DESC;
            """,
            (session["user_id"],),
        )
        my_donations = db_fetch_all(
            """
            SELECT d.id, bg.blood_group, d.created_at
            FROM donors d
            JOIN blood_groups bg ON bg.id=d.blood_group_id
            WHERE d.user_id=%s
            ORDER BY d.created_at DESC;
            """,
            (session["user_id"],),
        )
        return render_template("dashboard.html", requests=requests_, donations=my_donations)

    # ------------------------------
    # Admin routes
    # ------------------------------

    @app.route("/admin", methods=["GET", "POST"])
    def admin():
        """
        Admin portal: if already logged in, shows dashboard with counts.
        If not logged in, shows login form.
        """
        if session.get("admin_id"):
            # Admin is logged in – fetch counts for dashboard
            donors_count = db_fetch_one("SELECT COUNT(*)::int AS c FROM donors;")["c"]
            queries_count = db_fetch_one("SELECT COUNT(*)::int AS c FROM contact_queries;")["c"]
            pending_queries = db_fetch_one("SELECT COUNT(*)::int AS c FROM contact_queries WHERE status=2;")["c"]
            pending_requests = db_fetch_one("SELECT COUNT(*)::int AS c FROM blood_requests WHERE status='pending';")["c"]
            return render_template(
                "admin.html",
                view="dashboard",
                donors_count=donors_count,
                queries_count=queries_count,
                pending_queries=pending_queries,
                pending_requests=pending_requests,
            )

        # Admin not logged in – process login form
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            admin_row = db_fetch_one(
                "SELECT id, name, username, password_hash FROM admins WHERE username=%s;",
                (username,),
            )
            if not admin_row or not check_password_hash(admin_row["password_hash"], password):
                flash("Username and password are not matched!", "danger")
                return render_template("admin.html", view="login")

            session.clear()
            session["admin_id"] = admin_row["id"]
            session["admin_username"] = admin_row["username"]
            session["admin_name"] = admin_row["name"]
            flash("Admin login successful.", "success")
            return redirect(url_for("admin"))

        # GET request – show login form
        return render_template("admin.html", view="login")

    @app.get("/admin/logout")
    def admin_logout():
        """Admin logout – clears session and redirects to admin login page."""
        session.clear()
        flash("Admin logged out.", "info")
        return redirect(url_for("admin"))

    @app.get("/admin/donors")
    @admin_login_required
    def admin_donors():
        """
        Admin: list all donors with full details.
        """
        rows = db_fetch_all(
            """
            SELECT d.id, d.name, d.phone, d.email, d.age, d.gender, d.address, bg.blood_group
            FROM donors d
            JOIN blood_groups bg ON bg.id=d.blood_group_id
            ORDER BY d.id DESC;
            """
        )
        return render_template("admin_donors.html", donors=rows, blood_groups=_blood_groups())

    @app.route("/admin/donors/add", methods=["GET", "POST"])
    @admin_login_required
    def admin_add_donor():
        """
        Admin: add a new donor manually (same fields as public registration).
        """
        if request.method == "POST":
            name = request.form.get("fullname", "").strip()
            phone = request.form.get("mobileno", "").strip()
            email = request.form.get("emailid", "").strip() or None
            age = request.form.get("age", "").strip()
            gender = request.form.get("gender", "").strip()
            blood_group_id = request.form.get("blood")
            address = request.form.get("address", "").strip()

            if not (name and phone and age and gender and blood_group_id and address):
                flash("Please fill all required fields.", "danger")
                return redirect(url_for("admin_add_donor"))

            try:
                age_int = int(age)
            except ValueError:
                flash("Age must be a number.", "danger")
                return redirect(url_for("admin_add_donor"))

            db_execute(
                """
                INSERT INTO donors(name, phone, email, age, gender, blood_group_id, address)
                VALUES (%s,%s,%s,%s,%s,%s,%s);
                """,
                (name, phone, email, age_int, gender, int(blood_group_id), address),
            )
            flash("Donor added successfully.", "success")
            return redirect(url_for("admin_donors"))
        return render_template("admin_donor_form.html", blood_groups=_blood_groups(), donor=None)

    @app.route("/admin/donors/<int:donor_id>/edit", methods=["GET", "POST"])
    @admin_login_required
    def admin_edit_donor(donor_id: int):
        """
        Admin: edit an existing donor's details.
        """
        donor = db_fetch_one(
            """
            SELECT id, name, phone, email, age, gender, blood_group_id, address
            FROM donors WHERE id=%s;
            """,
            (donor_id,),
        )
        if not donor:
            abort(404)
        if request.method == "POST":
            name = request.form.get("fullname", "").strip()
            phone = request.form.get("mobileno", "").strip()
            email = request.form.get("emailid", "").strip() or None
            age = request.form.get("age", "").strip()
            gender = request.form.get("gender", "").strip()
            blood_group_id = request.form.get("blood")
            address = request.form.get("address", "").strip()
            if not (name and phone and age and gender and blood_group_id and address):
                flash("Please fill all required fields.", "danger")
                return redirect(url_for("admin_edit_donor", donor_id=donor_id))
            try:
                age_int = int(age)
            except ValueError:
                flash("Age must be a number.", "danger")
                return redirect(url_for("admin_edit_donor", donor_id=donor_id))

            db_execute(
                """
                UPDATE donors
                SET name=%s, phone=%s, email=%s, age=%s, gender=%s, blood_group_id=%s, address=%s
                WHERE id=%s;
                """,
                (name, phone, email, age_int, gender, int(blood_group_id), address, donor_id),
            )
            flash("Donor updated successfully.", "success")
            return redirect(url_for("admin_donors"))
        return render_template("admin_donor_form.html", blood_groups=_blood_groups(), donor=donor)

    @app.post("/admin/donors/<int:donor_id>/delete")
    @admin_login_required
    def admin_delete_donor(donor_id: int):
        """
        Admin: delete a donor record.
        """
        db_execute("DELETE FROM donors WHERE id=%s;", (donor_id,))
        flash("Donor deleted.", "info")
        return redirect(url_for("admin_donors"))

    @app.get("/admin/stock")
    @admin_login_required
    def admin_stock():
        """
        Admin: view and edit blood stock levels.
        Shows current stock for each blood group.
        """
        stock = db_fetch_all(
            """
            SELECT bg.id AS blood_group_id, bg.blood_group, COALESCE(bs.units,0) AS units, bs.updated_at
            FROM blood_groups bg
            LEFT JOIN blood_stock bs ON bs.blood_group_id = bg.id
            ORDER BY bg.blood_group;
            """
        )
        return render_template("admin_stock.html", stock=stock)

    @app.post("/admin/stock/update")
    @admin_login_required
    def admin_stock_update():
        """
        Admin: update the number of units for a specific blood group.
        Uses INSERT ... ON CONFLICT to update or insert.
        """
        blood_group_id = int(request.form.get("blood_group_id"))
        units = request.form.get("units", "0").strip()
        try:
            units_int = max(0, int(units))
        except ValueError:
            flash("Units must be a number.", "danger")
            return redirect(url_for("admin_stock"))

        db_execute(
            """
            INSERT INTO blood_stock(blood_group_id, units, updated_at)
            VALUES (%s,%s,NOW())
            ON CONFLICT (blood_group_id)
            DO UPDATE SET units=EXCLUDED.units, updated_at=NOW();
            """,
            (blood_group_id, units_int),
        )
        flash("Blood stock updated.", "success")
        return redirect(url_for("admin_stock"))

    @app.get("/admin/requests")
    @admin_login_required
    def admin_requests():
        """
        Admin: list all blood requests with details.
        """
        rows = db_fetch_all(
            """
            SELECT br.id, br.requester_name, br.requester_phone, br.requester_email,
                   bg.blood_group, br.units_requested, br.reason, br.status, br.requested_at
            FROM blood_requests br
            JOIN blood_groups bg ON bg.id=br.blood_group_id
            ORDER BY br.requested_at DESC;
            """
        )
        return render_template("admin_requests.html", requests=rows)

    @app.post("/admin/requests/<int:req_id>/status")
    @admin_login_required
    def admin_request_status(req_id: int):
        """
        Admin: update the status of a blood request (pending, approved, rejected, fulfilled).
        Also records the admin who processed it and the timestamp.
        """
        status = request.form.get("status", "pending").strip()
        if status not in {"pending", "approved", "rejected", "fulfilled"}:
            flash("Invalid status.", "danger")
            return redirect(url_for("admin_requests"))
        db_execute(
            """
            UPDATE blood_requests
            SET status=%s, processed_at=NOW(), processed_by_admin_id=%s
            WHERE id=%s;
            """,
            (status, session["admin_id"], req_id),
        )
        flash("Request status updated.", "success")
        return redirect(url_for("admin_requests"))

    @app.post("/admin/requests/<int:req_id>/delete")
    @admin_login_required
    def admin_request_delete(req_id: int):
        """
        Admin: delete a blood request.
        """
        db_execute("DELETE FROM blood_requests WHERE id=%s;", (req_id,))
        flash("Request deleted.", "info")
        return redirect(url_for("admin_requests"))

    @app.get("/admin/queries")
    @admin_login_required
    def admin_queries():
        """
        Admin: list all contact queries.
        """
        rows = db_fetch_all(
            """
            SELECT id, name, email, phone, message, created_at, status
            FROM contact_queries
            ORDER BY created_at DESC;
            """
        )
        return render_template("admin_queries.html", queries=rows)

    @app.post("/admin/queries/<int:query_id>/read")
    @admin_login_required
    def admin_query_read(query_id: int):
        """
        Admin: mark a query as read (status=1).
        """
        db_execute("UPDATE contact_queries SET status=1 WHERE id=%s;", (query_id,))
        flash("Query marked as read.", "success")
        return redirect(url_for("admin_queries"))

    @app.post("/admin/queries/<int:query_id>/delete")
    @admin_login_required
    def admin_query_delete(query_id: int):
        """
        Admin: delete a query.
        """
        db_execute("DELETE FROM contact_queries WHERE id=%s;", (query_id,))
        flash("Query deleted.", "info")
        return redirect(url_for("admin_queries"))

    @app.get("/admin/pages")
    @admin_login_required
    def admin_pages():
        """
        Admin: list all editable pages (from the 'pages' table).
        """
        pages = db_fetch_all("SELECT id, name, type, data FROM pages ORDER BY id;")
        return render_template("admin_pages.html", pages=pages)

    @app.route("/admin/pages/<string:page_type>", methods=["GET", "POST"])
    @admin_login_required
    def admin_page_edit(page_type: str):
        """
        Admin: edit the content of a specific page (identified by its type).
        The page content is stored in the 'data' column (text).
        """
        page = db_fetch_one("SELECT id, name, type, data FROM pages WHERE type=%s;", (page_type,))
        if not page:
            abort(404)
        if request.method == "POST":
            data = request.form.get("data", "")
            db_execute("UPDATE pages SET data=%s WHERE type=%s;", (data, page_type))
            flash("Page updated successfully.", "success")
            return redirect(url_for("admin_pages"))
        return render_template("admin_page_edit.html", page=page)

    @app.route("/admin/contact-info", methods=["GET", "POST"])
    @admin_login_required
    def admin_contact_info():
        """
        Admin: edit the global contact information (address, email, phone) displayed on the contact page.
        """
        info = db_fetch_one("SELECT id, address, email, phone FROM contact_info ORDER BY id LIMIT 1;")
        if request.method == "POST":
            address = request.form.get("address", "").strip()
            email = request.form.get("email", "").strip()
            phone = request.form.get("phone", "").strip()
            if not (address and email and phone):
                flash("Please fill all fields.", "danger")
                return redirect(url_for("admin_contact_info"))
            if info:
                db_execute(
                    "UPDATE contact_info SET address=%s, email=%s, phone=%s WHERE id=%s;",
                    (address, email, phone, info["id"]),
                )
            else:
                db_execute("INSERT INTO contact_info(address,email,phone) VALUES (%s,%s,%s);", (address, email, phone))
            flash("Contact info updated successfully.", "success")
            return redirect(url_for("admin_contact_info"))
        return render_template("admin_contact_info.html", info=info)

    return app


# Create the application instance
app = create_app()


def _init_db():
    """
    Helper function to initialize the database by executing schema.sql.
    Called when the script is run with --init-db.
    """
    schema_path = BASE_DIR / "schema.sql"
    if not schema_path.exists():
        print("schema.sql not found.", file=sys.stderr)
        return 2
    sql = schema_path.read_text(encoding="utf-8")
    conn = psycopg2.connect(_build_dsn())
    conn.autocommit = True
    try:
        with conn.cursor() as cur:
            cur.execute(sql)
    finally:
        conn.close()
    print("Database initialized successfully.")
    return 0


if __name__ == "__main__":
    # If command-line argument --init-db is provided, run database initialization and exit
    if len(sys.argv) > 1 and sys.argv[1] == "--init-db":
        raise SystemExit(_init_db())
    # Otherwise run the Flask development server
    app.run(host="127.0.0.1", port=5000, debug=True)